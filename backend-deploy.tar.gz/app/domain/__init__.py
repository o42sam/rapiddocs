"""
Domain layer for RapidDocs.
Contains business logic, entities, value objects, and interfaces.
This layer has no external dependencies.
"""