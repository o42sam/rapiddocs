"""
Application layer for RapidDocs.
Contains use cases, application services, and orchestrators.
This layer orchestrates domain logic and infrastructure services.
"""