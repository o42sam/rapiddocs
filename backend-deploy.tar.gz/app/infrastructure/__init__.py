"""
Infrastructure layer for RapidDocs.
Contains concrete implementations of domain interfaces.
This layer handles external dependencies and technical details.
"""