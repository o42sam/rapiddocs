# DocGen Backend Deployment Guide

This guide covers deploying the DocGen backend to a Hostinger VPS with the frontend hosted on Firebase.

## Architecture Overview

- **Backend**: FastAPI application running on Hostinger VPS
- **Frontend**: React/TypeScript SPA hosted on Firebase
- **Database**: MongoDB Atlas (cloud-hosted)
- **File Storage**: Local VPS storage
- **SSL**: Let's Encrypt via Certbot
- **Reverse Proxy**: Nginx
- **Process Manager**: systemd with Gunicorn

## Prerequisites

### VPS Requirements
- Ubuntu 22.04 LTS
- Minimum 2GB RAM (4GB recommended)
- 20GB storage minimum
- Python 3.9+
- Root or sudo access

### Domain Setup
- Domain pointed to VPS IP (e.g., api.yourdomain.com)
- DNS A record configured

### Required Accounts
- MongoDB Atlas account with cluster configured
- Google Cloud account for Gemini API
- HuggingFace account for image generation (optional)

## Quick Deployment

### Step 1: Initial VPS Setup

SSH into your VPS and run the setup script:

```bash
# Download and run setup script
wget https://raw.githubusercontent.com/yourusername/docgen/master/backend/setup-vps.sh
chmod +x setup-vps.sh
sudo ./setup-vps.sh
```

This script will:
- Update system packages
- Install Python, Nginx, and dependencies
- Configure firewall
- Create application user
- Set up SSL certificates
- Configure fail2ban for security
- Set up monitoring and backups

### Step 2: Deploy Application

From your local machine:

```bash
cd backend
./deploy.sh --host YOUR_VPS_IP --user root
```

This will:
- Sync code to VPS
- Install Python dependencies
- Copy configuration files
- Set up systemd service
- Configure Nginx
- Start the application

### Step 3: Configure Environment

SSH into VPS and edit the production environment:

```bash
sudo su - docgen
cd backend
nano .env.production
```

Update these critical settings:
```bash
# MongoDB Atlas connection
MONGODB_URL=mongodb+srv://username:password@cluster.mongodb.net/dbname

# AI Services
GEMINI_API_KEY=your-gemini-api-key
HUGGINGFACE_API_KEY=your-huggingface-key

# JWT Secrets (generate new ones!)
JWT_SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")
JWT_REFRESH_SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")

# CORS - Add your Firebase domains
CORS_ORIGINS=https://yourapp.web.app,https://yourapp.firebaseapp.com

# Google OAuth (if using)
GOOGLE_CLIENT_ID=your-client-id
GOOGLE_CLIENT_SECRET=your-client-secret
```

### Step 4: Start Services

```bash
# Start and enable the backend service
sudo systemctl start docgen-backend
sudo systemctl enable docgen-backend

# Check status
sudo systemctl status docgen-backend

# View logs
sudo journalctl -u docgen-backend -f
```

## Manual Deployment Steps

### 1. System Preparation

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y python3 python3-pip python3-venv nginx certbot python3-certbot-nginx git

# Create application user
sudo useradd -m -s /bin/bash docgen
sudo usermod -a -G www-data docgen
```

### 2. Application Setup

```bash
# Switch to app user
sudo su - docgen

# Clone repository (or copy files)
git clone https://github.com/yourusername/docgen.git
cd docgen/backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements-production.txt
```

### 3. Configure Gunicorn

Copy `gunicorn_production.conf.py` to `/home/docgen/backend/`

Key settings:
- Workers: `(2 × CPU cores) + 1`
- Worker class: `uvicorn.workers.UvicornWorker`
- Bind: `127.0.0.1:8000` (localhost only, Nginx will proxy)

### 4. Configure systemd Service

```bash
# Copy service file
sudo cp docgen-backend.service /etc/systemd/system/

# Reload systemd
sudo systemctl daemon-reload

# Enable service
sudo systemctl enable docgen-backend
```

### 5. Configure Nginx

```bash
# Copy nginx config
sudo cp nginx-production.conf /etc/nginx/sites-available/docgen-api

# Enable site
sudo ln -s /etc/nginx/sites-available/docgen-api /etc/nginx/sites-enabled/

# Remove default site
sudo rm -f /etc/nginx/sites-enabled/default

# Test configuration
sudo nginx -t

# Reload Nginx
sudo systemctl reload nginx
```

### 6. SSL Setup

```bash
# Obtain SSL certificate
sudo certbot --nginx -d api.yourdomain.com

# Test auto-renewal
sudo certbot renew --dry-run
```

## Directory Structure

```
/home/docgen/
├── backend/                 # Application code
│   ├── app/                 # FastAPI application
│   ├── venv/                # Python virtual environment
│   ├── .env.production      # Production environment variables
│   └── gunicorn_production.conf.py
├── uploads/                 # User uploads
├── generated_pdfs/          # Generated documents
└── logs/                    # Application logs

/var/log/docgen/            # Service logs
/var/run/docgen/            # PID files
/backup/docgen/             # Backup location
```

## Environment Variables

Critical environment variables in `.env.production`:

| Variable | Description | Example |
|----------|-------------|---------|
| `APP_ENV` | Environment | `production` |
| `DEBUG` | Debug mode | `False` |
| `MONGODB_URL` | MongoDB connection | `mongodb+srv://...` |
| `GEMINI_API_KEY` | Google Gemini API | `AIza...` |
| `JWT_SECRET_KEY` | JWT signing key | Generate with secrets |
| `CORS_ORIGINS` | Allowed origins | Firebase URLs |

## Service Management

### Start/Stop Service

```bash
# Start
sudo systemctl start docgen-backend

# Stop
sudo systemctl stop docgen-backend

# Restart
sudo systemctl restart docgen-backend

# Status
sudo systemctl status docgen-backend
```

### View Logs

```bash
# Service logs
sudo journalctl -u docgen-backend -f

# Nginx access logs
sudo tail -f /var/log/nginx/docgen-api-access.log

# Nginx error logs
sudo tail -f /var/log/nginx/docgen-api-error.log

# Application logs
tail -f /var/log/docgen/service.log
```

## Monitoring

### Health Checks

```bash
# Basic health check
curl http://localhost:8000/health

# Detailed health check
curl http://localhost:8000/health/detailed

# Readiness probe
curl http://localhost:8000/health/ready
```

### System Monitoring

The setup includes basic monitoring that checks:
- Disk usage
- Memory usage
- Service status

View monitoring logs:
```bash
tail -f /var/log/docgen/monitor.log
```

## Backup and Restore

### Manual Backup

```bash
sudo /usr/local/bin/docgen-backup

# Or with the provided script
cd /home/docgen/backend
./backup.sh backup
```

### Scheduled Backups

Automatic daily backups at 2 AM via cron:
```bash
# View backup schedule
crontab -l

# List backups
./backup.sh list
```

### Restore from Backup

```bash
# Restore from specific date
./backup.sh restore --date 20240121
```

## Updating the Application

### Deploy Updates

From your local machine:
```bash
cd backend
./deploy.sh --host YOUR_VPS_IP --user root
```

### Manual Update

On the VPS:
```bash
# Pull latest code
cd /home/docgen/backend
git pull origin master

# Activate venv and update dependencies
source venv/bin/activate
pip install -r requirements-production.txt

# Restart service
sudo systemctl restart docgen-backend
```

## Security Considerations

### Firewall Rules

```bash
# Check firewall status
sudo ufw status

# Only these ports should be open:
# - 22 (SSH)
# - 80 (HTTP)
# - 443 (HTTPS)
```

### fail2ban Protection

Configured to protect against:
- SSH brute force
- Nginx bad bots
- Rate limit violations

Check fail2ban status:
```bash
sudo fail2ban-client status
sudo fail2ban-client status nginx-limit-req
```

### SSL Configuration

- TLS 1.2 and 1.3 only
- Strong ciphers
- HSTS enabled
- OCSP stapling

Test SSL configuration:
```bash
# Using SSL Labs
# Visit: https://www.ssllabs.com/ssltest/analyze.html?d=api.yourdomain.com
```

## Troubleshooting

### Service Won't Start

```bash
# Check service status
sudo systemctl status docgen-backend

# Check for port conflicts
sudo lsof -i :8000

# Verify Python path
which python3
/home/docgen/backend/venv/bin/python --version

# Check permissions
ls -la /home/docgen/
ls -la /var/log/docgen/
```

### 502 Bad Gateway

```bash
# Check if backend is running
sudo systemctl status docgen-backend

# Check Nginx error logs
sudo tail -f /var/log/nginx/docgen-api-error.log

# Test backend directly
curl http://localhost:8000/health

# Check Gunicorn logs
sudo journalctl -u docgen-backend -n 100
```

### MongoDB Connection Issues

```bash
# Test MongoDB connection
python3 -c "
from pymongo import MongoClient
client = MongoClient('your-connection-string')
print(client.list_database_names())
"

# Check firewall for MongoDB Atlas IPs
# Ensure VPS IP is whitelisted in MongoDB Atlas
```

### High Memory Usage

```bash
# Check memory usage
free -h
htop

# Restart service to free memory
sudo systemctl restart docgen-backend

# Adjust Gunicorn workers in gunicorn_production.conf.py
# workers = 2  # Reduce if needed
```

## Performance Tuning

### Gunicorn Optimization

Edit `gunicorn_production.conf.py`:
```python
# Adjust based on VPS resources
workers = 3  # (2 × CPU cores) + 1
worker_connections = 1000
max_requests = 1000  # Restart workers after N requests
max_requests_jitter = 50
```

### Nginx Caching

Nginx is configured with caching for:
- Static files (1 hour)
- API responses (1 minute for GET requests)

Clear cache if needed:
```bash
sudo rm -rf /var/cache/nginx/docgen/*
sudo systemctl reload nginx
```

### Database Indexes

Ensure MongoDB indexes are created:
```python
# In MongoDB Atlas or via script
db.documents.createIndex({"job_id": 1})
db.documents.createIndex({"created_at": -1})
db.users.createIndex({"email": 1})
```

## Monitoring and Alerts

### Set Up External Monitoring

Consider using:
- UptimeRobot for uptime monitoring
- New Relic or DataDog for APM
- Sentry for error tracking

### Log Aggregation

For production, consider:
- ELK Stack (Elasticsearch, Logstash, Kibana)
- Grafana Loki
- CloudWatch (if using AWS)

## Disaster Recovery

### Regular Backups

Ensure backups are working:
```bash
# Test backup
./backup.sh backup

# Verify backup files
ls -la /backup/docgen/daily/
```

### Backup to Remote Storage

Configure remote backup in `backup.sh`:
```bash
REMOTE_BACKUP_HOST="backup.server.com"
REMOTE_BACKUP_DIR="/backups/docgen"
```

Or use cloud storage:
- AWS S3
- Google Cloud Storage
- Backblaze B2

### Recovery Time Objective (RTO)

With proper backups:
- Full restore: 10-15 minutes
- Service restart: 1-2 minutes
- DNS propagation: 0-48 hours (if changing servers)

## Support and Maintenance

### Regular Tasks

Weekly:
- Check disk usage: `df -h`
- Review logs for errors
- Verify backups are running

Monthly:
- Update system packages: `sudo apt update && sudo apt upgrade`
- Review security logs
- Test restore procedure

Quarterly:
- Update Python dependencies
- Review and rotate API keys
- Performance audit

### Getting Help

1. Check logs first:
   - Application logs: `/var/log/docgen/`
   - Nginx logs: `/var/log/nginx/`
   - System logs: `journalctl`

2. Test endpoints:
   - Health: `curl https://api.yourdomain.com/health`
   - API docs: `https://api.yourdomain.com/api/v1/docs`

3. Common issues:
   - Most issues are configuration-related
   - Check environment variables
   - Verify service is running
   - Check network connectivity

## Additional Resources

- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [Gunicorn Documentation](https://docs.gunicorn.org/)
- [Nginx Documentation](https://nginx.org/en/docs/)
- [MongoDB Atlas Documentation](https://docs.atlas.mongodb.com/)
- [Systemd Documentation](https://systemd.io/)

---

Last Updated: January 2025
Version: 1.0.0