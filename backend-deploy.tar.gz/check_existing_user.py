"""
Check existing user in MongoDB to understand password format.
"""

import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo.server_api import ServerApi
import bcrypt
import os
from dotenv import load_dotenv

load_dotenv()

async def check_user():
    """Check test user in database"""
    # Connect to MongoDB
    mongodb_url = os.environ.get('MONGODB_URL')
    db_name = os.environ.get('MONGODB_DB_NAME', 'docgen')

    print(f"Connecting to MongoDB...")
    client = AsyncIOMotorClient(
        mongodb_url,
        server_api=ServerApi('1'),
        serverSelectionTimeoutMS=30000
    )

    db = client[db_name]

    # Find test user
    user = await db.users.find_one({'email': 'test@rapiddocs.io'})

    if user:
        print("\n✅ Found test user:")
        print(f"  Email: {user.get('email')}")
        print(f"  Username: {user.get('username')}")
        print(f"  Has password field: {'password' in user}")
        print(f"  Has password_hash field: {'password_hash' in user}")

        if 'password' in user:
            pwd_value = user['password']
            print(f"  Password field type: {type(pwd_value)}")
            print(f"  Password field length: {len(str(pwd_value))}")
            # Check if it looks like bcrypt hash
            if isinstance(pwd_value, str) and pwd_value.startswith('$2'):
                print(f"  ✅ Password appears to be bcrypt hash")

                # Test if 'testuser' matches
                test_password = 'testuser'
                if bcrypt.checkpw(test_password.encode('utf-8'), pwd_value.encode('utf-8')):
                    print(f"  ✅ Password 'testuser' matches the hash!")
                else:
                    print(f"  ❌ Password 'testuser' does NOT match the hash")
            else:
                print(f"  ⚠️ Password doesn't look like bcrypt hash")

        # Check hashed_password field
        if 'hashed_password' in user:
            hashed_pwd = user['hashed_password']
            print(f"\n  Hashed password field:")
            print(f"    Type: {type(hashed_pwd)}")
            print(f"    Starts with: {hashed_pwd[:10] if hashed_pwd else 'None'}")

            # Test if 'testuser' matches
            test_password = 'testuser'
            try:
                if bcrypt.checkpw(test_password.encode('utf-8'), hashed_pwd.encode('utf-8')):
                    print(f"    ✅ Password 'testuser' matches the hash!")
                else:
                    print(f"    ❌ Password 'testuser' does NOT match")
            except Exception as e:
                print(f"    ❌ Error checking password: {e}")

        print(f"\n  Other fields in user document:")
        for key in user.keys():
            if key not in ['_id', 'password', 'email', 'username', 'hashed_password']:
                print(f"    - {key}: {type(user[key]).__name__}")
    else:
        print("❌ Test user test@rapiddocs.io not found in database")

    # Check all users
    print("\n📊 All users in database:")
    async for user in db.users.find():
        print(f"  - {user.get('email', 'No email')} (username: {user.get('username', 'N/A')})")

    client.close()

if __name__ == "__main__":
    asyncio.run(check_user())