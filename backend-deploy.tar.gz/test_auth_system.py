"""
Test authentication system with existing database user.
"""

import asyncio
import os
import sys
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo.server_api import ServerApi
from dotenv import load_dotenv

# Add app to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.infrastructure.persistence.mongodb_user_repository import MongoDBUserRepository
from app.infrastructure.auth.jwt_auth_service import JWTAuthService
from app.application.use_cases.login_user import LoginUserUseCase
from app.application.dto.auth_request import LoginRequest

load_dotenv()

async def test_auth():
    """Test the complete auth flow with existing user."""

    # Connect to MongoDB
    mongodb_url = os.environ.get('MONGODB_URL')
    db_name = os.environ.get('MONGODB_DB_NAME', 'docgen')

    print(f"1. Connecting to MongoDB...")
    client = AsyncIOMotorClient(
        mongodb_url,
        server_api=ServerApi('1'),
        serverSelectionTimeoutMS=30000
    )

    db = client[db_name]
    print(f"   ✅ Connected to {db_name}")

    # Initialize repository
    print("\n2. Initializing repository...")
    user_repository = MongoDBUserRepository(db)

    # Test get user by email
    print("\n3. Looking up user test@rapiddocs.io...")
    user = await user_repository.get_user_by_email("test@rapiddocs.io")

    if user:
        print(f"   ✅ Found user:")
        print(f"      Email: {user.email}")
        print(f"      Name: {user.name}")
        print(f"      ID: {user.id}")
        print(f"      Has password hash: {bool(user.password_hash)}")
        print(f"      Password hash starts with: {user.password_hash[:10] if user.password_hash else 'None'}")

        # Test password verification directly
        print("\n4. Testing password verification...")
        password = "testuser"
        is_valid = user.verify_password(password)
        print(f"   Password 'testuser' verification: {'✅ VALID' if is_valid else '❌ INVALID'}")

        if not is_valid:
            # Debug the password hash format
            print(f"\n   Debug info:")
            print(f"   - Password hash: {user.password_hash[:30]}...")
            print(f"   - Hash starts with $2: {user.password_hash.startswith('$2')}")

            # Try bcrypt directly
            import bcrypt
            try:
                is_valid_bcrypt = bcrypt.checkpw(
                    password.encode('utf-8'),
                    user.password_hash.encode('utf-8')
                )
                print(f"   - Direct bcrypt check: {'✅ VALID' if is_valid_bcrypt else '❌ INVALID'}")
            except Exception as e:
                print(f"   - Direct bcrypt error: {e}")

        # Test JWT auth service
        print("\n5. Testing JWT auth service...")
        auth_service = JWTAuthService(
            user_repository=user_repository,
            secret_key=os.environ.get("JWT_SECRET_KEY", "your-secret-key-change-in-production"),
            algorithm="HS256",
            access_token_expire_minutes=60,
            refresh_token_expire_days=7
        )

        # Test login use case
        print("\n6. Testing login use case...")
        login_use_case = LoginUserUseCase(
            user_repository=user_repository,
            auth_service=auth_service
        )

        login_request = LoginRequest(
            email="test@rapiddocs.io",
            password="testuser"
        )

        try:
            result = await login_use_case.execute(login_request)
            print(f"   ✅ Login successful!")
            print(f"      Access token: {result.tokens.access_token[:30]}...")
        except Exception as e:
            print(f"   ❌ Login failed: {e}")

    else:
        print(f"   ❌ User not found in database")

        # List all users to debug
        print("\n   Listing all users in database:")
        async for u in db.users.find():
            print(f"   - {u.get('email', 'No email')} (ID: {u.get('_id')})")

    client.close()

if __name__ == "__main__":
    asyncio.run(test_auth())